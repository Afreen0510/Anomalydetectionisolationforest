"""Exercise an already started Compose stack with a fresh labeled batch."""
import json
from pathlib import Path
import subprocess
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]


def search(index, query):
    request = Request(f"http://127.0.0.1:9200/{index}/_search",
                      data=json.dumps({"size": 100, "query": query}).encode(),
                      headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=8) as response:
        return [hit["_source"] for hit in json.load(response)["hits"]["hits"]]


def main():
    with urlopen("http://127.0.0.1:8000/products", timeout=10) as response:
        assert json.load(response)["products"]
    run_id = subprocess.check_output([
        "docker", "compose", "exec", "-T", "app", "python", "demo.py", "emit",
        "--normal", "40", "--anomalies", "8",
    ], cwd=ROOT, text=True).strip()
    query = {"term": {"run_id": run_id}}
    deadline = time.monotonic() + 240
    while time.monotonic() < deadline:
        raw = search("cloud-logs", query)
        scored = search("cloud-anomalies", query)
        if len(raw) == len(scored) == 48:
            assert {x["event_id"] for x in raw} == {x["event_id"] for x in scored}
            injected = [x for x in scored if x["demo_anomaly"]]
            assert len(injected) == 8 and all(x["is_anomaly"] for x in injected)
            assert any(not x["is_anomaly"] for x in scored if not x["demo_anomaly"])
            print(f"Run {run_id}: 48 events indexed and scored, 8 injected anomalies flagged.")
            return
        time.sleep(3)
    raise SystemExit(f"Timed out for {run_id}: {len(raw)} raw, {len(scored)} scored")


if __name__ == "__main__":
    main()
