#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
base="${KIBANA_URL:-http://127.0.0.1:5601}"
for attempt in {1..90}; do
  if curl -fsS "$base/api/status" >/dev/null 2>&1; then
    curl -fsS -X POST "$base/api/saved_objects/_import?overwrite=true" \
      -H 'kbn-xsrf: true' -F file=@kibana/dashboard.ndjson |
      python3 -c 'import json,sys; r=json.load(sys.stdin); print(json.dumps(r, indent=2)); sys.exit(not r.get("success", False))'
    exit
  fi
  sleep 3
done
echo "Kibana did not become ready" >&2
exit 1
